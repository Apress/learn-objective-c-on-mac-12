#import "Tire.h"

@interface AllWeatherRadial : Tire
@end // AllWeatherRadial

