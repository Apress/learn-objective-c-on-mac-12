//
//  SelectorTester.h
//  Selectors
//
//  Created by Waqar Malik on 4/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SelectorTester : NSObject

- (void)runSelectors;
@end
