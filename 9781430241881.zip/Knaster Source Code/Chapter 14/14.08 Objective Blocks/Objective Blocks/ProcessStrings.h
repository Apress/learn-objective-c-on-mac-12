//
//  ProcessStrings.h
//  Objective Blocks
//
//  Created by Waqar Malik on 4/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProcessStrings : NSObject
@property (strong) NSString *theString;

- (void)testMyString;
@end
