//
//  Tire.m
//  CarParts-Copy
//
//  Created by Waqar Malik on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Slant6.h"

@implementation Slant6

- (NSString *)description
{
    return (@"I am a slant-6. VROOOM!");
} // description

@end // Slant6

