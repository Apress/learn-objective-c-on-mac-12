//
//  Worker2.m
//  Delegation
//
//  Created by Waqar Malik on 3/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Worker2.h"

@implementation Worker2

- (void)doSomeRequiredWork
{
    NSLog(@"Worker2 doing required work.");
}

- (void)doSomeOptionalWork
{
    NSLog(@"Worker2 doing optional work.");
}
@end
