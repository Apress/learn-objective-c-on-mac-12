//
//  AllWeatherRadial.h
//  CarParts-Copy
//
//  Created by Waqar Malik on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Tire.h"

@interface AllWeatherRadial : Tire

@property (assign) float rainHandling;
@property (assign) float snowHandling;

@end // AllWeatherRadial
