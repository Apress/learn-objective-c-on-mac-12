#import "Engine.h"

@interface Slant6 : Engine
@end // Slant6

