//
//  Thing1.m
//  CategoryThing
//
//  Created by Waqar Malik on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CategoryThing.h"

@implementation CategoryThing (Thing1)
- (void)setThing1:(NSInteger)t1
{
    thing1 = t1;
} // setThing1

- (NSInteger) thing1
{
    return (thing1);
} // thing1

@end // CategoryThing
