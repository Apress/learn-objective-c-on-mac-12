//
//  Worker1.m
//  Delegation
//
//  Created by Waqar Malik on 3/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Worker1.h"

@implementation Worker1

- (void)doSomeRequiredWork
{
    NSLog(@"Worker1 doing required work.");
}
@end
