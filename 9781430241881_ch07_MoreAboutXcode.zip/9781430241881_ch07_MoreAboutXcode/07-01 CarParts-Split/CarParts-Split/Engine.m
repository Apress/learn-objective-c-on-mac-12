#import "Engine.h"

@implementation Engine

- (NSString *) description
{
    return (@"I am an engine.  Vrooom!");
} // description

@end // Engine

